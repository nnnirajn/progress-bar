$('#html').LineProgressbar({
  
    percentage: 90,
    ShowProgressCount: true,
    duration: 2000,
    fillBackgroundColor: '#8b0000',
    backgroundColor: '#EEEEEE',
    radius: '20px',
    height: '25px',
    width: '100%'

  });

  $('#css').LineProgressbar({
  
    percentage: 80,
    ShowProgressCount: true,
    duration: 2000,
    fillBackgroundColor: '#FF0000',
    backgroundColor: '#EEEEEE',
    radius: '20px',
    height: '25px',
    width: '100%'

  });

  $('#js').LineProgressbar({
  
    percentage: 30,
    ShowProgressCount: true,
    duration: 2000,
    fillBackgroundColor: '#008000',
    backgroundColor: '#EEEEEE',
    radius: '20px',
    height: '25px',
    width: '100%'

  });

  $('#jq').LineProgressbar({
  
    percentage: 20,
    ShowProgressCount: true,
    duration: 2000,
    fillBackgroundColor: '#3498db',
    backgroundColor: '#EEEEEE',
    radius: '20px',
    height: '25px',
    width: '100%'

  });

  $('#php').LineProgressbar({
  
    percentage: 60,
    ShowProgressCount: true,
    duration: 2000,
    fillBackgroundColor: '#8A2BE2',
    backgroundColor: '#EEEEEE',
    radius: '20px',
    height: '25px',
    width: '100%'

  });
  